window.history.scrollRestoration = "manual";
window.scrollTo(0, 0);

const exploreMenuLink = document.querySelector("#explore-menu");
const introAboutLink = document.querySelector("#intro-about");
const welcomeScreen = document.querySelector("#welcome-screen");
const introSlides = Array.from(document.querySelectorAll(".intro-hero-image"));
const introDots = Array.from(document.querySelectorAll(".intro-dot"));
const reducedMotionQuery = window.matchMedia("(prefers-reduced-motion: reduce)");
const header = document.querySelector(".header");
const logoImage = document.querySelector(".logo");
const logoWordmark = document.querySelector(".logo-wordmark");
const menuSelectorFrame = document.querySelector("#menu-selector-frame");
const mobileMenuQuery = window.matchMedia("(max-width: 768px)");
const narrowDesktopMenuQuery = window.matchMedia("(min-width: 769px) and (max-width: 1024px)");
const wideDesktopMenuQuery = window.matchMedia("(min-width: 1025px)");
let drinkDropdownOpen = false;
const pizzaList = document.querySelector(".pizza-list");
const pizzaSection = document.querySelector("#pizza-section");
const coffeeSection = document.querySelector("#coffee-section");
const coffeeList = document.querySelector("#coffee-list");
const dessertSection = document.querySelector("#dessert-section");
const dessertList = document.querySelector("#dessert-list");
const alcoholSection = document.querySelector("#alcohol-section");

introSlides.slice(1).forEach((slide) => {
    const preload = new Image();
    preload.src = slide.src;
});

let activeIntroSlide = 0;
let introSlideTimer;

function showIntroSlide(index) {
    activeIntroSlide = (index + introSlides.length) % introSlides.length;
    introSlides.forEach((slide, slideIndex) => {
        slide.classList.toggle("is-active", slideIndex === activeIntroSlide);
    });
    introDots.forEach((dot, dotIndex) => {
        const isActive = dotIndex === activeIntroSlide;
        dot.classList.toggle("is-active", isActive);
        dot.setAttribute("aria-pressed", String(isActive));
    });
}

function stopIntroSlideshow() {
    window.clearInterval(introSlideTimer);
    introSlideTimer = undefined;
}

function startIntroSlideshow() {
    stopIntroSlideshow();
    if (reducedMotionQuery.matches || document.hidden || introSlides.length < 2) return;
    introSlideTimer = window.setInterval(() => {
        showIntroSlide(activeIntroSlide + 1);
    }, 4500);
}

introDots.forEach((dot) => {
    dot.addEventListener("click", () => {
        showIntroSlide(Number(dot.dataset.slideTo));
        startIntroSlideshow();
    });
});

document.addEventListener("visibilitychange", startIntroSlideshow);
reducedMotionQuery.addEventListener("change", startIntroSlideshow);
startIntroSlideshow();

function sendMenuSelectorLayout(compact = true) {
    const mobile = mobileMenuQuery.matches;
    menuSelectorFrame.contentWindow.postMessage({
        type: "kuma-menu-selector-compact",
        compact,
        mobile,
        headerHeight: Math.ceil(header.getBoundingClientRect().height),
        viewportHeight: window.innerHeight,
        desktopNarrow: narrowDesktopMenuQuery.matches,
        desktopWide: wideDesktopMenuQuery.matches
    }, "*");
}

function updateMenuSelectorLayout() {
    menuSelectorFrame.style.height = mobileMenuQuery.matches ? "64px" : narrowDesktopMenuQuery.matches ? "72px" : "76px";
    document.body.classList.toggle("drink-menu-open", mobileMenuQuery.matches && drinkDropdownOpen);
    sendMenuSelectorLayout(true);
}

if (logoImage && logoWordmark) {
    const showLogoWordmark = () => {
        logoImage.hidden = true;
        logoWordmark.hidden = false;
    };
    logoImage.addEventListener("error", showLogoWordmark, { once: true });
    if (logoImage.complete && !logoImage.naturalWidth) showLogoWordmark();
}

function getDiscountedPrice(price, discountPercent) {
    return Math.max(1, Math.round(price * (100 - discountPercent) / 100));
}

function getRandomDiscountPercent() {
    return Math.floor(Math.random() * 16) + 10;
}

const { coffeeCatalogData, dessertCatalogData } = window.menuData;

const coffeeCatalog = coffeeCatalogData
    .map(({ file, label, price }) => [file, label, price])
    .sort((a, b) => a[0].localeCompare(b[0], "en"));

const coffeeVariants = Object.fromEntries(
    coffeeCatalogData
        .filter(({ variant }) => variant)
        .map(({ file, variant }) => [file, variant])
);

const coffeeFantasyNames = new Map(
    coffeeCatalogData.map(({ file, fantasy }) => [file, fantasy])
);

const coffeeMeta = Object.fromEntries(
    coffeeCatalogData.map(({ file, meta }) => [file, meta ?? {}])
);

const dessertCatalog = dessertCatalogData.map(({ file }) => file);
const dessertFantasyNames = new Map(
    dessertCatalogData.map(({ file, fantasy }) => [file, fantasy])
);
const dessertTags = {
    extraSweet: new Set(dessertCatalogData.filter(({ tags }) => tags?.includes("extraSweet")).map(({ file }) => file)),
    hit: new Set(dessertCatalogData.filter(({ tags }) => tags?.includes("hit")).map(({ file }) => file)),
    pie: new Set(dessertCatalogData.filter(({ tags }) => tags?.includes("pie")).map(({ file }) => file)),
    cheesecake: new Set(dessertCatalogData.filter(({ tags }) => tags?.includes("cheesecake")).map(({ file }) => file)),
    sale: new Set(dessertCatalogData.filter(({ tags }) => tags?.includes("sale")).map(({ file }) => file))
};
const dessertPrices = new Map(
    dessertCatalogData.map(({ file, price }) => [file, price])
);

coffeeCatalog.forEach(([imageName, displayLabel, price]) => {
    const fileName = imageName.replace(/\.jpg$/i, "");
    const coffeeName = displayLabel || fileName;
    const fantasyName = coffeeFantasyNames.get(imageName);
    if (!fantasyName) {
        throw new Error(`Missing fantasy name for ${imageName}`);
    }
    const coffeeItem = document.createElement("article");
    coffeeItem.className = "pizza-item coffee-item";
    const variant = coffeeVariants[imageName];
    const meta = coffeeMeta[imageName] || {};
    const isCold = (meta.tags || []).includes("cold");

    if (meta.promoted) coffeeItem.classList.add("is-promoted");
    if (meta.badge?.text.toLowerCase() === "hit") coffeeItem.classList.add("is-hit");
    if (meta.spicy) coffeeItem.classList.add("is-spicy");
    if (meta.isNew) coffeeItem.classList.add("is-new");
    if (isCold) coffeeItem.classList.add("is-cold");

    coffeeItem.dataset.fantasyName = fantasyName;
    coffeeItem.dataset.name = `${fantasyName} (${coffeeName}) ${coffeeName} ${fileName} ${variant?.label || ""}`.toLowerCase();
    const isSale = meta.badge?.text.toLowerCase() === "sale"
        || (meta.tags || []).includes("sale");
    const discountPercent = isSale ? getRandomDiscountPercent() : 0;
    if (isSale) {
        coffeeItem.dataset.promo = "true";
        coffeeItem.dataset.discountPercent = String(discountPercent);
    }

    const badges = [];
    if (meta.badge && meta.badge.tone !== "cold") {
        badges.push(`<span class="tavern-badge tavern-badge--${meta.badge.tone}">${meta.badge.text}</span>`);
    }
    if (isCold) badges.push('<span class="tavern-badge tavern-badge--cold">Cold</span>');
    const badgeMarkup = badges.length ? `<div class="coffee-badges">${badges.join("")}</div>` : "";

    coffeeItem.innerHTML = `
        ${badgeMarkup}
        <h2 class="pizza-name"><span class="coffee-fantasy-name">${fantasyName}</span><span class="coffee-real-name">(${coffeeName})</span></h2>
        <img src="Images for it/Coffee/${imageName}" alt="${coffeeName}" width="400" height="400" loading="lazy" decoding="async">
        ${variant ? `<label class="coffee-variant-toggle" aria-label="${variant.toggleLabel}"><input class="coffee-variant" type="checkbox"><span>${variant.toggleLabel}</span></label>` : ""}
        <div class="tavern-card-footer">
            <p${isSale ? ' class="promo-price"' : ""}>${isSale ? `<span class="old-price">${price} UAH</span><span class="discount-percent">-${discountPercent}%</span><strong class="price current-price">Price: ${getDiscountedPrice(price, discountPercent)} UAH</strong>` : `<strong class="price">Price: ${price} UAH</strong>`}</p>
            <button class="tavern-add" type="button" aria-label="Add ${fantasyName} (${coffeeName}) to cart">+</button>
        </div>
    `;

    coffeeList.append(coffeeItem);

    const addButton = coffeeItem.querySelector(".tavern-add");
    addButton.addEventListener("click", (event) => {
        event.stopPropagation();
        const priceElement = coffeeItem.querySelector(".price");
        addToCart(getCoffeeDisplayName(coffeeItem), priceElement.textContent, "Coffee");
    });

    coffeeItem.dataset.tags = [...new Set([...(meta.tags || []), ...(isSale ? ["sale"] : [])])].join(" ");

    if (variant) {
        const coffeeImage = coffeeItem.querySelector("img");
        const coffeeRealName = coffeeItem.querySelector(".coffee-real-name");
        const coffeePrice = coffeeItem.querySelector(".price");

        coffeeItem.querySelectorAll(".coffee-variant").forEach((checkbox) => {
            checkbox.addEventListener("click", (event) => event.stopPropagation());
            checkbox.addEventListener("change", () => {
                const isLarge = checkbox.checked;
                coffeeImage.classList.add("is-changing");
                window.setTimeout(() => {
                    coffeeImage.src = `Images for it/Coffee/${isLarge ? variant.image : imageName}`;
                    coffeeImage.alt = isLarge ? variant.label : coffeeName;
                    const realLabel = isLarge ? variant.label.replace(/\s+\(([^)]+)\)$/, ", $1") : coffeeName;
                    coffeeRealName.textContent = `(${realLabel})`;
                    const selectedPrice = isLarge ? variant.price : price;
                    const discount = Number(coffeeItem.dataset.discountPercent || 0);
                    const oldPrice = coffeeItem.querySelector(".old-price");
                    if (oldPrice) oldPrice.textContent = `${selectedPrice} UAH`;
                    coffeePrice.textContent = `Price: ${discount ? getDiscountedPrice(selectedPrice, discount) : selectedPrice} UAH`;
                    coffeeImage.classList.remove("is-changing");
                }, 220);
            });
        });
    }
});

const dessertTagLabels = {
    extraSweet: "Extra sweet",
    hit: "Hit",
    pie: "Pie",
    cheesecake: "Cheesecake",
    sale: "Sale"
};

dessertCatalog.forEach((imageName) => {
    const dessertName = dessertFantasyNames.get(imageName);
    if (!dessertName) {
        throw new Error(`Missing fantasy name for ${imageName}`);
    }
    const price = dessertPrices.get(imageName);
    if (price === undefined) {
        throw new Error(`Missing dessert price for ${imageName}`);
    }
    const dessertItem = document.createElement("article");
    dessertItem.className = "coffee-item dessert-item";
    dessertItem.dataset.name = `${dessertName} ${imageName}`.toLowerCase();
    const tags = Object.entries(dessertTags)
        .filter(([, images]) => images.has(imageName))
        .map(([tag]) => tag);
    const isSale = tags.includes("sale");
    const discountPercent = isSale ? getRandomDiscountPercent() : 0;
    const displayPrice = isSale ? getDiscountedPrice(price, discountPercent) : price;
    if (isSale) dessertItem.dataset.discountPercent = String(discountPercent);
    dessertItem.dataset.tags = tags
        .map((tag) => tag.replace(/[A-Z]/g, (letter) => `-${letter.toLowerCase()}`))
        .join(" ");
    const tagMarkup = tags.map((tag) =>
        `<span class="dessert-tag tavern-badge tavern-badge--${tag.replace(/[A-Z]/g, (letter) => `-${letter.toLowerCase()}`)}">${dessertTagLabels[tag]}</span>`
    ).join("");
    dessertItem.innerHTML = `
        <h2 class="pizza-name">${dessertName}</h2>
        ${tagMarkup ? `<div class="dessert-tags" aria-label="Dessert tags">${tagMarkup}</div>` : ""}
        <img src="Images for it/Desserts/${imageName}" alt="${dessertName}" width="400" height="400" loading="lazy" decoding="async">
        <div class="tavern-card-footer">
            <p${isSale ? ' class="promo-price"' : ""}>${isSale ? `<span class="old-price">${price} UAH</span><span class="discount-percent">-${discountPercent}%</span><strong class="price current-price">Price: ${displayPrice} UAH</strong>` : `<strong class="price">Price: ${price} UAH</strong>`}</p>
            <button class="tavern-add" type="button" aria-label="Add ${dessertName} to order">+</button>
        </div>
    `;
    dessertList.append(dessertItem);

    dessertItem.querySelector(".tavern-add").addEventListener("click", (event) => {
        event.stopPropagation();
        addToCart(dessertName, dessertItem.querySelector(".current-price, .price").textContent, "Desserts");
    });
});

const coffeeSearch = document.querySelector("#coffee-search");
const coffeeChips = document.querySelectorAll("[data-coffee-filter]");
const coffeeFilterbar = document.querySelector("#coffee-filterbar");
const coffeeFilterToggle = document.querySelector("#coffee-filter-toggle");
let activeCoffeeFilter = "all";

function applyCoffeeFilters() {
    const query = (coffeeSearch?.value || "").trim().toLowerCase();
    coffeeList.querySelectorAll(".coffee-item").forEach((item) => {
        const matchesQuery = !query || (item.dataset.name || "").includes(query);
        const matchesFilter = activeCoffeeFilter === "all"
            || (item.dataset.tags || "").split(" ").includes(activeCoffeeFilter);
        item.hidden = !(matchesQuery && matchesFilter);
    });
    orderCoffeeProducts();
    updateFeaturedDivider(coffeeList);
}

function orderCoffeeProducts() {
    const divider = coffeeList.querySelector(":scope > .featured-divider");
    if (!divider) return;

    const items = Array.from(coffeeList.querySelectorAll(":scope > .coffee-item"));
    const featured = items.filter((item) => item.classList.contains("featured-product"));
    const other = items.filter((item) => !item.classList.contains("featured-product"));
    const orderedItems = activeCoffeeFilter === "all"
        ? [...featured, divider, ...other]
        : [...other, divider, ...featured];

    coffeeList.append(...orderedItems);
}

coffeeChips.forEach((chip) => {
    chip.addEventListener("click", () => {
        activeCoffeeFilter = chip.dataset.coffeeFilter;
        coffeeChips.forEach((button) => button.classList.toggle("is-active", button === chip));
        applyCoffeeFilters();
    });
});

if (coffeeSearch) {
    coffeeSearch.addEventListener("input", () => {
        applyCoffeeFilters();
        updateCategorySuggestions(coffeeSection);
    });
}

const dessertSearch = document.querySelector("#dessert-search");
const dessertChips = document.querySelectorAll("[data-dessert-filter]");
let activeDessertFilter = "all";

function applyDessertFilters() {
    const query = (dessertSearch?.value || "").trim().toLowerCase();
    dessertList.querySelectorAll(".dessert-item").forEach((item) => {
        const matchesQuery = !query || item.dataset.name.includes(query);
        const matchesFilter = activeDessertFilter === "all"
            || item.dataset.tags.split(" ").includes(activeDessertFilter);
        item.hidden = !(matchesQuery && matchesFilter);
    });
}

dessertChips.forEach((chip) => {
    chip.addEventListener("click", () => {
        activeDessertFilter = chip.dataset.dessertFilter;
        dessertChips.forEach((button) => {
            const isActive = button === chip;
            button.classList.toggle("is-active", isActive);
            button.setAttribute("aria-pressed", String(isActive));
        });
        applyDessertFilters();
    });
});

if (dessertSearch) {
    dessertSearch.addEventListener("input", () => {
        applyDessertFilters();
        updateCategorySuggestions(dessertSection);
    });
}

const dessertFilterbar = document.querySelector("#dessert-filterbar");
const dessertFilterToggle = document.querySelector("#dessert-filter-toggle");
const filterDisclosurePairs = [
    [document.querySelector("#pizza-filterbar"), document.querySelector("#pizza-filter-toggle")],
    [document.querySelector("#coffee-filterbar"), document.querySelector("#coffee-filter-toggle")],
    [dessertFilterbar, dessertFilterToggle]
];

function setFilterPanelOpen(filterbar, toggle, isOpen) {
    filterbar.classList.toggle("filters-open", isOpen);
    toggle.setAttribute("aria-expanded", String(isOpen));
}

filterDisclosurePairs.forEach(([filterbar, toggle]) => {
    if (!filterbar || !toggle) return;

    toggle.addEventListener("click", () => {
        setFilterPanelOpen(filterbar, toggle, toggle.getAttribute("aria-expanded") !== "true");
    });

    filterbar.querySelector(".tavern-chips")?.addEventListener("click", (event) => {
        const chip = event.target.closest(".tavern-chip");
        if (!chip || !chip.classList.contains("is-active")) return;
        toggle.classList.toggle("has-active-filter", chip.textContent.trim().toLowerCase() !== "all");
    });
});

function closeOpenFilterPanels(event) {
    if (!window.matchMedia("(max-width: 768px)").matches) return;
    filterDisclosurePairs.forEach(([filterbar, toggle]) => {
        if (filterbar?.classList.contains("filters-open") && (!event || !filterbar.contains(event.target))) {
            setFilterPanelOpen(filterbar, toggle, false);
        }
    });
}

document.addEventListener("pointerdown", closeOpenFilterPanels);

document.addEventListener("keydown", (event) => {
    if (event.key !== "Escape" || !window.matchMedia("(max-width: 768px)").matches) return;
    closeOpenFilterPanels();
});

function startWelcome() {
    if (document.body.classList.contains("welcome-started")) return;
    document.body.classList.add("welcome-started");
    document.body.classList.add("welcome-fading");
}

exploreMenuLink.addEventListener("click", (event) => {
    event.preventDefault();
    window.history.pushState({ kumaView: "menu", section: "pizza" }, "", window.location.href);
    startWelcome();
    openMenuSection("pizza");
});
let categorySwitchTimer;
let categoryTitleAnimationTimer;
let categoryTitleOverlay;
let categoryTitleElement;
let activeMenuSelection = null;
let menuScrollTimer;
let menuTransitionTimer;

function openMenuSection(section) {
    const detail = { section, sub: null };
    activeMenuSelection = detail;
    document.dispatchEvent(new CustomEvent("menusection", { detail }));
}

function switchProductSection(activeName) {
    const sections = [pizzaSection || pizzaList, coffeeSection, dessertSection, alcoholSection].filter(Boolean);
    const previousTitle = document.querySelector(".tavern-category.category-visible .tavern-hero-title");
    window.clearTimeout(categoryTitleAnimationTimer);
    categoryTitleOverlay?.remove();
    categoryTitleOverlay = null;
    if (categoryTitleElement) {
        categoryTitleElement.style.opacity = "";
        categoryTitleElement.style.width = "";
        categoryTitleElement = null;
    }
    const sectionMap = {
        pizza: pizzaSection || pizzaList,
        coffee: coffeeSection,
        desserts: dessertSection,
        alcohol: alcoholSection
    };
    const activeSection = sectionMap[activeName] || null;
    window.clearTimeout(categorySwitchTimer);
    document.querySelectorAll(".tavern-hero-title").forEach((title) => {
        title.style.width = "";
    });
    document.body.classList.add("category-switching");

    sections.forEach((section) => {
        const isActive = section === activeSection;
        section.hidden = !isActive;
        section.classList.remove("category-visible");
        section.classList.toggle("category-hidden", !isActive);
    });

    const activeTitle = activeSection ? activeSection.querySelector(".tavern-hero-title") : null;
    if (activeTitle && previousTitle && previousTitle !== activeTitle) {
        const startRect = previousTitle.getBoundingClientRect();
        const targetRect = activeTitle.getBoundingClientRect();
        categoryTitleOverlay = previousTitle.cloneNode(true);
        categoryTitleOverlay.classList.add("category-title-transition");
        categoryTitleOverlay.removeAttribute("id");
        categoryTitleOverlay.querySelectorAll("[id]").forEach((element) => element.removeAttribute("id"));
        Object.assign(categoryTitleOverlay.style, {
            position: "fixed",
            top: `${startRect.top}px`,
            left: "50%",
            width: `${startRect.width}px`,
            maxWidth: "min(900px, calc(100vw - 40px))",
            boxSizing: "border-box",
            margin: "0",
            transform: "translateX(-50%)",
            zIndex: "10000",
            pointerEvents: "none"
        });
        categoryTitleOverlay.innerHTML = activeTitle.innerHTML;
        document.body.append(categoryTitleOverlay);
        activeTitle.style.opacity = "0";
        categoryTitleElement = activeTitle;
        void categoryTitleOverlay.offsetWidth;
        window.requestAnimationFrame(() => {
            categoryTitleOverlay.style.width = `${targetRect.width}px`;
            categoryTitleOverlay.style.top = `${targetRect.top}px`;
        });
        categoryTitleAnimationTimer = window.setTimeout(() => {
            categoryTitleOverlay?.remove();
            categoryTitleOverlay = null;
            activeTitle.style.opacity = "";
            categoryTitleElement = null;
        }, 850);
    }

    window.requestAnimationFrame(() => {
        window.requestAnimationFrame(() => {
            if (activeSection && document.body.classList.contains("menu-choice-made")) {
                activeSection.classList.add("category-visible");
                activeSection.classList.remove("category-hidden");
            }
        });
    });

    categorySwitchTimer = window.setTimeout(() => {
        sections.forEach((section) => {
            section.hidden = section !== activeSection;
        });
        document.body.classList.remove("category-switching");
    }, 400);
}

function moveMenuSelectorToHeader() {
    const startRect = menuSelectorFrame.getBoundingClientRect();
    header.append(menuSelectorFrame);
    header.append(aboutButton);
    menuSelectorFrame.style.height = mobileMenuQuery.matches ? "64px" : narrowDesktopMenuQuery.matches ? "72px" : "76px";
    sendMenuSelectorLayout(true);
    const endRect = menuSelectorFrame.getBoundingClientRect();
    const deltaX = startRect.left - endRect.left;
    const deltaY = startRect.top - endRect.top;
    const scaleX = startRect.width / endRect.width;
    const scaleY = startRect.height / endRect.height;

    menuSelectorFrame.animate([
        { transform: `translate(${deltaX}px, ${deltaY}px) scale(${scaleX}, ${scaleY})`, transformOrigin: "top left" },
        { transform: "translate(0, 0) scale(1, 1)", transformOrigin: "top left" }
    ], {
        duration: 850,
        easing: "cubic-bezier(0.22, 1, 0.36, 1)"
    });
}

function syncMenuSelectorTheme(theme) {
    menuSelectorFrame.contentWindow.postMessage({
        type: "kuma-menu-selector-theme",
        theme
    }, "*");
}

function selectMenuSection(sectionName) {
    const isPizzaTab = sectionName === "pizza";
    const isCoffeeTab = sectionName === "coffee";
    const isFirstCategoryChoice = !document.body.classList.contains("menu-choice-made");
    window.clearTimeout(menuScrollTimer);
    window.clearTimeout(menuTransitionTimer);
    document.body.classList.add("menu-choice-transition");

    if (isFirstCategoryChoice) {
        document.body.classList.add("menu-initial-entry");
        moveMenuSelectorToHeader();
    }

    document.body.classList.add("menu-choice-made");
    document.body.classList.remove("page-end-reached");
    document.body.classList.toggle("pizza-open", isPizzaTab);
    document.body.classList.toggle("coffee-theme", isCoffeeTab);
    document.body.classList.toggle("drawer-open", isCoffeeTab);
    document.body.classList.toggle("dessert-open", sectionName === "desserts");
    document.body.classList.toggle("alcohol-open", sectionName === "alcohol");
    [
        [pizzaFilterbar, pizzaFilterToggle],
        [coffeeFilterbar, coffeeFilterToggle],
        [dessertFilterbar, dessertFilterToggle]
    ].forEach(([filterbar, toggle]) => {
        if (filterbar && toggle) setFilterPanelOpen(filterbar, toggle, false);
    });
    syncMenuSelectorTheme(isPizzaTab ? "pizza" : isCoffeeTab ? "drinks" : sectionName === "desserts" ? "desserts" : "default");

    switchProductSection(sectionName);
    updatePageEndVisibility();

    menuScrollTimer = window.setTimeout(() => {
        window.scrollTo({ top: 0, behavior: "instant" });
    }, isFirstCategoryChoice ? 760 : 520);

    menuTransitionTimer = window.setTimeout(() => {
        document.body.classList.remove("menu-choice-transition");
        document.body.classList.remove("menu-initial-entry");
    }, isFirstCategoryChoice ? 760 : 520);
}

window.addEventListener("message", (event) => {
    if (event.source !== menuSelectorFrame.contentWindow) return;
    const { type, detail, height } = event.data || {};

    if (type === "kuma-menu-selector-size" && Number.isFinite(height)) {
        menuSelectorFrame.style.height = `${height}px`;
    } else if (type === "kuma-menu-selector-dropdown" && typeof event.data.open === "boolean") {
        drinkDropdownOpen = event.data.open;
        document.body.classList.toggle("drink-menu-open", mobileMenuQuery.matches && drinkDropdownOpen);
    } else if (type === "kuma-menu-selector-selection" && detail) {
        document.dispatchEvent(new CustomEvent("menusection", { detail }));
    }
});

document.addEventListener("menusection", (event) => {
    const { section, sub } = event.detail || {};
    const sectionName = section === "drinks"
        ? ({ Coffee: "coffee" })[sub]
        : section;

    if (["pizza", "coffee", "desserts", "alcohol"].includes(sectionName)) {
        activeMenuSelection = { section, sub: sub || null };
        menuSelectorFrame.contentWindow.postMessage({
            type: "kuma-menu-selector-state",
            selection: activeMenuSelection
        }, "*");
        selectMenuSection(sectionName);
    }
});

menuSelectorFrame.addEventListener("load", () => {
    menuSelectorFrame.contentDocument.addEventListener("pointerdown", closeOpenFilterPanels);
    menuSelectorFrame.contentDocument.addEventListener("keydown", (event) => {
        if (event.key === "Escape") closeOpenFilterPanels();
    });
    updateMenuSelectorLayout();
    syncMenuSelectorTheme(document.body.classList.contains("pizza-open")
        ? "pizza"
        : document.body.classList.contains("coffee-theme") ? "drinks"
            : document.body.classList.contains("dessert-open") ? "desserts" : "default");
    updatePageEndVisibility();
    if (activeMenuSelection) {
        menuSelectorFrame.contentWindow.postMessage({
            type: "kuma-menu-selector-state",
            selection: activeMenuSelection
        }, "*");
    }
});

[mobileMenuQuery, narrowDesktopMenuQuery, wideDesktopMenuQuery].forEach((query) => {
    query.addEventListener("change", updateMenuSelectorLayout);
});

window.addEventListener("resize", updateMenuSelectorLayout);

function returnToIntro() {
    window.clearTimeout(menuScrollTimer);
    window.clearTimeout(menuTransitionTimer);
    window.clearTimeout(categorySwitchTimer);
    window.clearTimeout(categoryTitleAnimationTimer);
    categoryTitleOverlay?.remove();
    categoryTitleOverlay = null;
    categoryTitleElement?.removeAttribute("style");
    categoryTitleElement = null;
    activeMenuSelection = null;
    syncMenuSelectorTheme("default");
    document.body.classList.remove(
        "welcome-started",
        "welcome-fading",
        "menu-choice-made",
        "menu-choice-transition",
        "menu-initial-entry",
        "category-switching",
        "pizza-open",
        "coffee-theme",
        "drawer-open",
        "dessert-open",
        "alcohol-open",
        "about-footer-open"
    );
    welcomeScreen.scrollTop = 0;
    updatePageEndVisibility();
    [pizzaSection, coffeeSection, dessertSection, alcoholSection].filter(Boolean).forEach((section) => {
        section.hidden = true;
        section.classList.remove("category-visible", "category-hidden");
    });
    window.scrollTo({ top: 0, behavior: "auto" });
}

window.addEventListener("popstate", (event) => {
    if (event.state?.kumaView === "intro") {
        returnToIntro();
    } else if (event.state?.kumaView === "menu") {
        startWelcome();
        openMenuSection("pizza");
    }
});

document.addEventListener("click", (event) => {
    if (!menuSelectorFrame.contains(event.target)) {
        menuSelectorFrame.contentWindow.postMessage({ type: "kuma-menu-selector-close" }, "*");
    }
});

document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") {
        menuSelectorFrame.contentWindow.postMessage({
            type: "kuma-menu-selector-close",
            focus: true
        }, "*");
        if (!aboutScreen.hidden) closeAboutScreen();
    }
});

let downwardScrollCount = 0;

window.addEventListener("wheel", (event) => {
    if (!document.body.classList.contains("welcome-started")) return;

    if (event.deltaY > 0) {
        downwardScrollCount += 1;
        if (downwardScrollCount >= 4) document.body.classList.add("header-hidden");
    } else if (event.deltaY < 0) {
        downwardScrollCount = 0;
        document.body.classList.remove("header-hidden");
    }
}, { passive: true });

const menuItems = document.querySelectorAll(".pizza-item, .coffee-item, .dessert-item");

const detailScreen = document.createElement("section");
detailScreen.className = "pizza-detail";
detailScreen.innerHTML = `
    <button class="pizza-detail-close" type="button" aria-label="Close details">&times;</button>
    <div class="pizza-detail-card">
        <h2 class="pizza-detail-name"></h2>
        <img class="pizza-detail-image" alt="" width="600" height="400" loading="lazy" decoding="async">
        <p class="pizza-detail-price"></p>
        <div class="pizza-detail-actions">
            <button class="pizza-detail-button pizza-detail-order" type="button">Add to order</button>
            <button class="pizza-detail-button pizza-detail-more" type="button">More details</button>
        </div>
        <p class="pizza-detail-description" hidden></p>
    </div>
`;
document.body.append(detailScreen);

const detailName = detailScreen.querySelector(".pizza-detail-name");
const detailImage = detailScreen.querySelector(".pizza-detail-image");
const detailPrice = detailScreen.querySelector(".pizza-detail-price");
const detailDescription = detailScreen.querySelector(".pizza-detail-description");
const detailOrderButton = detailScreen.querySelector(".pizza-detail-order");
const detailMoreButton = detailScreen.querySelector(".pizza-detail-more");
const closeDetail = detailScreen.querySelector(".pizza-detail-close");

const cartFloat = document.querySelector("#cart-float");
const cartPanel = document.querySelector("#cart-panel");
const cartToggle = document.querySelector("#cart-toggle");
const cartClose = document.querySelector("#cart-close");
const cartCount = document.querySelector("#cart-count");
const cartItems = document.querySelector("#cart-items");
const cartTotal = document.querySelector("#cart-total");
const cartFilters = document.querySelectorAll("[data-cart-filter]");
const checkoutButton = document.querySelector("#checkout-button");
const checkoutMessage = document.querySelector("#checkout-message");
const deliveryButton = document.querySelector("#delivery-button");
const deliveryScreen = document.querySelector("#delivery-screen");
const deliveryClose = document.querySelector("#delivery-close");
const deliveryForm = document.querySelector("#delivery-form");
const aboutButton = document.querySelector("#about-button");
const aboutScreen = document.querySelector("#about-screen");
const aboutClose = document.querySelector("#about-close");

header.append(menuSelectorFrame, aboutButton);
updateMenuSelectorLayout();

const cartState = [];
let activeCartFilter = "all";
let lastMenuAboutVisibility = null;

function updatePageEndVisibility() {
    const isIntro = !document.body.classList.contains("welcome-started");
    const isNearPageEnd = isIntro
        ? welcomeScreen.scrollTop + welcomeScreen.clientHeight >= welcomeScreen.scrollHeight - 80
        : window.scrollY + window.innerHeight >= document.documentElement.scrollHeight - 80;

    introAboutLink.classList.toggle("visible", isNearPageEnd);
    aboutButton.classList.toggle("visible", isNearPageEnd);
    document.body.classList.toggle("page-end-reached", isNearPageEnd);
    if (lastMenuAboutVisibility !== isNearPageEnd) {
        menuSelectorFrame.contentWindow.postMessage({
            type: "kuma-menu-selector-about-visibility",
            visible: isNearPageEnd
        }, "*");
        lastMenuAboutVisibility = isNearPageEnd;
    }
}

window.addEventListener("scroll", updatePageEndVisibility, { passive: true });
window.addEventListener("resize", updatePageEndVisibility);
welcomeScreen.addEventListener("scroll", updatePageEndVisibility, { passive: true });
updatePageEndVisibility();

function extractPriceAsNumber(value) {
    const numbers = String(value).match(/\d+/g) ?? [];
    if (!numbers.length) return 0;
    const numericValues = numbers.map(Number);
    return numericValues.length >= 3 ? numericValues[numericValues.length - 2] : numericValues[numericValues.length - 1];
}

function renderCart() {
    cartItems.innerHTML = "";
    const visibleCartItems = activeCartFilter === "all" ? cartState : cartState.filter((item) => item.category === activeCartFilter);

    visibleCartItems.forEach((item) => {
        const cartItem = document.createElement("li");
        cartItem.className = "cart-item";
        cartItem.innerHTML = `
            <div class="cart-item-main">
                <span class="cart-item-name">${item.name}</span>
                <span class="cart-item-category">${item.category}</span>
                <span class="cart-item-price">${item.price} UAH</span>
            </div>
            <div class="cart-item-controls">
                <span class="cart-item-qty">x${item.quantity}</span>
                <button class="cart-item-remove" type="button" data-name="${item.name}" aria-label="Remove ${item.name}">×</button>
            </div>
        `;
        cartItems.append(cartItem);
    });

    const totalCount = cartState.reduce((sum, item) => sum + item.quantity, 0);
    const totalPrice = cartState.reduce((sum, item) => sum + item.price * item.quantity, 0);
    cartCount.textContent = String(totalCount);
    cartTotal.textContent = `${totalPrice} UAH`;

    if (totalCount > 0) {
        cartFloat.classList.add("has-items");
        cartToggle.setAttribute("aria-label", `${totalCount} items in cart`);
        document.body.classList.add("cart-has-items");
    } else {
        cartFloat.classList.remove("has-items");
        cartToggle.setAttribute("aria-label", "Cart is empty");
        document.body.classList.remove("cart-has-items");
    }

    document.querySelectorAll(".cart-item-remove").forEach((button) => {
        button.addEventListener("click", () => {
            const name = button.dataset.name;
            const index = cartState.findIndex((item) => item.name === name);
            if (index === -1) return;
            if (cartState[index].quantity > 1) {
                cartState[index].quantity -= 1;
            } else {
                cartState.splice(index, 1);
            }
            renderCart();
        });
    });
}

cartFilters.forEach((filterButton) => {
    filterButton.addEventListener("click", () => {
        activeCartFilter = filterButton.dataset.cartFilter;
        cartFilters.forEach((button) => button.classList.toggle("is-active", button === filterButton));
        renderCart();
    });
});

function addToCart(name, priceValue, category) {
    const existing = cartState.find((item) => item.name === name && item.category === category);
    if (existing) {
        existing.quantity += 1;
    } else {
        cartState.push({ name, price: extractPriceAsNumber(priceValue), category, quantity: 1 });
    }

    renderCart();
    cartPanel.hidden = false;
    cartFloat.classList.add("is-open");
    cartFloat.classList.remove("cart-bump");
    void cartFloat.offsetWidth;
    cartFloat.classList.add("cart-bump");
    window.clearTimeout(cartFloat.bumpTimer);
    cartFloat.bumpTimer = window.setTimeout(() => cartFloat.classList.remove("cart-bump"), 550);
}

function getCoffeeDisplayName(item) {
    const realName = item.querySelector(".coffee-real-name")?.textContent.trim().replace(/^\(|\)$/g, "");
    return `${item.dataset.fantasyName} (${realName})`;
}

function openProductDetail(item) {
    const name = item.querySelector(".pizza-name");
    const image = item.querySelector("img");
    const activePriceElement = item.querySelector(".current-price") || item.querySelector(".price");
    const price = item.querySelector(".promo-price, .price");
    const isDessert = item.classList.contains("dessert-item");
    const isCoffee = item.classList.contains("coffee-item") && !isDessert;
    const productCategory = isDessert ? "Desserts" : isCoffee ? "Coffee" : "Pizza";
    const pizzaSize = item.classList.contains("chef-item") ? "50 cm" : item.classList.contains("popular-item") ? "40 cm" : item.classList.contains("spicy-item") ? "30 cm" : "30 cm";
    const pizzaInfo = item.classList.contains("chef-item") ? "Sweet, wild, and made with fresh vegetables straight from the chef's kitchen." : item.classList.contains("popular-item") ? "A favorite among our loyal guests." : item.classList.contains("spicy-item") ? "Very spicy." : "Pizza for those who appreciate classic taste and simplicity.";
    const howOrder = item.classList.contains("chef-item") ? "Complimentary 2 bottles of wine or beer of your choice, up to 400 UAH." : item.classList.contains("popular-item") ? "Respect to you." : item.classList.contains("spicy-item") ? "Milk as a gift." : "No extra offer.";
    const coffeeSize = item.querySelector(".coffee-variant")?.checked ? "Larger version" : "Standard version";
    const productName = isCoffee ? getCoffeeDisplayName(item) : name.textContent.trim();

    if (isCoffee) {
        const fantasyName = document.createElement("span");
        const realName = document.createElement("span");
        fantasyName.textContent = item.dataset.fantasyName;
        realName.className = "coffee-detail-real-name";
        realName.textContent = item.querySelector(".coffee-real-name").textContent;
        detailName.replaceChildren(fantasyName, realName);
    } else {
        detailName.textContent = name.textContent;
    }
    detailName.dataset.productName = productName;
    detailName.dataset.category = productCategory;
    detailImage.src = image.src;
    detailImage.alt = image.alt;
    detailPrice.textContent = activePriceElement ? activePriceElement.textContent.trim() : (price ? price.textContent.trim() : "");
    detailPrice.dataset.priceNumber = String(extractPriceAsNumber(detailPrice.textContent));
    detailDescription.textContent = isDessert
        ? `A sweet treat from our dessert menu.`
        : isCoffee
            ? `Version: ${coffeeSize}\nBriefly: ${productName} — aromatic coffee for a pleasant pause.`
            : `Pizza size: ${pizzaSize}\nBriefly: ${pizzaInfo}\nWhat it gives: ${howOrder}`;
    detailDescription.hidden = true;
    detailMoreButton.textContent = "More details";
    detailScreen.classList.add("is-visible");
    document.body.classList.add("detail-open");
}

function closePizzaDetail() {
    detailScreen.classList.remove("is-visible");
    document.body.classList.remove("detail-open");
    detailDescription.hidden = true;
    detailMoreButton.textContent = "More details";
}

menuItems.forEach((item) => item.addEventListener("click", () => openProductDetail(item)));
closeDetail.addEventListener("click", closePizzaDetail);
detailScreen.addEventListener("click", (event) => {
    if (event.target === detailScreen) closePizzaDetail();
});

detailOrderButton.addEventListener("click", () => {
    const pizzaName = detailName.dataset.productName || detailName.textContent.trim();
    const pizzaPrice = detailPrice.dataset.priceNumber || detailPrice.textContent.trim();
    addToCart(pizzaName, pizzaPrice, detailName.dataset.category);
    closePizzaDetail();
});

detailMoreButton.addEventListener("click", () => {
    const isHidden = detailDescription.hidden;
    detailDescription.hidden = !isHidden;
    detailMoreButton.textContent = isHidden ? "Hide" : "More details";
});

cartToggle.addEventListener("click", () => {
    const isOpen = cartFloat.classList.contains("is-open");
    cartFloat.classList.toggle("is-open", !isOpen);
    cartPanel.hidden = isOpen;
});

cartClose.addEventListener("click", () => {
    cartFloat.classList.remove("is-open");
    cartPanel.hidden = true;
});

checkoutButton.addEventListener("click", () => {
    checkoutMessage.hidden = false;
    window.clearTimeout(checkoutMessage.hideTimer);
    checkoutMessage.hideTimer = window.setTimeout(() => checkoutMessage.hidden = true, 2500);
});

deliveryButton.addEventListener("click", () => {
    deliveryScreen.hidden = false;
    document.body.classList.add("detail-open");
});

function closeDeliveryScreen() {
    deliveryScreen.hidden = true;
    document.body.classList.remove("detail-open");
}

deliveryClose.addEventListener("click", closeDeliveryScreen);
deliveryScreen.addEventListener("click", (event) => {
    if (event.target === deliveryScreen) closeDeliveryScreen();
});

deliveryForm.addEventListener("submit", (event) => {
    event.preventDefault();
    closeDeliveryScreen();
    checkoutMessage.textContent = "In development";
    checkoutMessage.hidden = false;
    window.clearTimeout(checkoutMessage.hideTimer);
    checkoutMessage.hideTimer = window.setTimeout(() => checkoutMessage.hidden = true, 2500);
});

function openAboutScreen() {
    aboutScreen.hidden = false;
    document.body.classList.add("detail-open");
}

introAboutLink.addEventListener("click", (event) => {
    event.preventDefault();
    openAboutScreen();
});

aboutButton.addEventListener("click", openAboutScreen);

function closeAboutScreen() {
    aboutScreen.hidden = true;
    document.body.classList.remove("detail-open");
}

aboutClose.addEventListener("click", closeAboutScreen);
aboutScreen.addEventListener("click", (event) => {
    if (event.target === aboutScreen) closeAboutScreen();
});

function decoratePizzaItems() {
    document.querySelectorAll(".pizza-list .pizza-item").forEach((item) => {
        if (item.dataset.decorated === "true") return;
        item.dataset.decorated = "true";

        const nameEl = item.querySelector(".pizza-name");
        const priceEl = item.querySelector(".price");
        if (nameEl && !nameEl.querySelector(".pizza-name-text")) {
            const nameText = document.createElement("span");
            nameText.className = "pizza-name-text";
            nameText.textContent = nameEl.textContent.trim();
            nameEl.replaceChildren(nameText);
        }
        const isPromo = item.classList.contains("promo-item");
        const isSpicy = item.classList.contains("spicy-item");
        const isChef = item.classList.contains("chef-item");
        const isPopular = item.classList.contains("popular-item");

        let badge = null;
        if (isPromo) badge = { text: "Sale", tone: "sale" };
        else if (isSpicy) badge = { text: "Spicy", tone: "spicy" };
        else if (isChef) badge = { text: "Chef's special", tone: "sale" };
        else if (isPopular) badge = { text: "Hit", tone: "new" };

        if (isPromo || isChef) item.classList.add("is-promoted");
        if (isSpicy) item.classList.add("is-spicy");
        if (isPopular) item.classList.add("is-new");

        if (badge) {
            const badgeEl = document.createElement("span");
            badgeEl.className = `tavern-badge tavern-badge--${badge.tone}`;
            badgeEl.textContent = badge.text;
            item.prepend(badgeEl);
        }

        const name = nameEl ? nameEl.textContent.trim() : "";
        item.dataset.name = name.toLowerCase();

        const tags = [];
        if (isSpicy) tags.push("spicy");
        if (isPromo || isChef) tags.push("sale");
        if (isPopular) tags.push("hit");
        if (["Goat's Secret", "Taleggio and Forest Nuts"].includes(name)) tags.push("veg");
        item.dataset.tags = tags.join(" ");

        if (isPromo || isChef) {
            const oldPriceElement = item.querySelector(".old-price");
            const basePrice = oldPriceElement
                ? extractPriceAsNumber(oldPriceElement.textContent)
                : extractPriceAsNumber(priceEl.textContent);
            const discountPercent = getRandomDiscountPercent();
            item.dataset.discountPercent = String(discountPercent);
            if (oldPriceElement) {
                oldPriceElement.textContent = `${basePrice} UAH`;
            } else {
                const oldPrice = document.createElement("span");
                oldPrice.className = "old-price";
                oldPrice.textContent = `${basePrice} UAH`;
                priceEl.parentElement.insertBefore(oldPrice, priceEl);
            }
            const discountBadge = document.createElement("span");
            discountBadge.className = "discount-percent";
            discountBadge.textContent = `-${discountPercent}%`;
            priceEl.parentElement.insertBefore(discountBadge, priceEl);
            priceEl.classList.add("current-price");
            priceEl.textContent = `Price: ${getDiscountedPrice(basePrice, discountPercent)} UAH`;
        }

        const addButton = document.createElement("button");
        addButton.type = "button";
        addButton.className = "tavern-add";
        addButton.setAttribute("aria-label", `Add ${name} to cart`);
        addButton.textContent = "+";
        addButton.addEventListener("click", (event) => {
            event.stopPropagation();
            const priceSource = item.querySelector(".current-price") || priceEl;
            addToCart(name, priceSource ? priceSource.textContent : "", "Pizza");
        });
        const footer = document.createElement("div");
        footer.className = "tavern-card-footer";
        const priceRow = item.querySelector(":scope > p");
        if (!priceRow) {
            throw new Error("Pizza card is missing its price row");
        }
        footer.append(priceRow, addButton);
        item.append(footer);
    });
}

decoratePizzaItems();
organizeFeaturedProducts(pizzaList, ".pizza-item", "pizza");
organizeFeaturedProducts(coffeeList, ".coffee-item", "coffee");

const pizzaSearch = document.querySelector("#pizza-search");
const pizzaChips = document.querySelectorAll("[data-pizza-filter]");
const pizzaFilterbar = document.querySelector("#pizza-filterbar");
const pizzaFilterToggle = document.querySelector("#pizza-filter-toggle");
let activePizzaFilter = "all";

function applyPizzaFilters() {
    if (!pizzaList) return;
    const query = (pizzaSearch?.value || "").trim().toLowerCase();
    pizzaList.querySelectorAll(".pizza-item").forEach((item) => {
        const matchesQuery = !query || (item.dataset.name || "").includes(query);
        const tags = (item.dataset.tags || "").split(" ");
        const matchesFilter = activePizzaFilter === "all" || tags.includes(activePizzaFilter);
        item.closest("li").hidden = !(matchesQuery && matchesFilter);
    });
    updateFeaturedDivider(pizzaList);
}

pizzaChips.forEach((chip) => {
    chip.addEventListener("click", () => {
        activePizzaFilter = chip.dataset.pizzaFilter;
        pizzaChips.forEach((button) => button.classList.toggle("is-active", button === chip));
        applyPizzaFilters();
    });
});

if (pizzaSearch) {
    pizzaSearch.addEventListener("input", () => {
        applyPizzaFilters();
        updateCategorySuggestions(pizzaSection);
    });
}

function getCategoryCardName(card) {
    if (card.classList.contains("coffee-item")) return getCoffeeDisplayName(card);
    const nameEl = card.querySelector(".pizza-name");
    return nameEl ? nameEl.textContent.trim() : "";
}

function organizeFeaturedProducts(list, itemSelector, category) {
    if (!list) return;

    const items = Array.from(list.querySelectorAll(itemSelector));
    const isSale = (item) => category === "pizza"
        ? item.classList.contains("promo-item")
        : Array.from(item.querySelectorAll(".tavern-badge")).some((badge) => badge.textContent.trim().toLowerCase() === "sale");
    const sales = items.filter(isSale);
    const featured = sales.length ? sales : items.filter((item) => {
        const labels = Array.from(item.querySelectorAll(".tavern-badge")).map((badge) => badge.textContent.trim().toLowerCase());
        return labels.includes("new") || labels.includes("hit") || item.classList.contains("popular-item");
    });

    if (!featured.length || featured.length === items.length) return;

    const featuredSet = new Set(featured);
    const entries = items.map((item) => {
        const node = item.closest("li") || item;
        node.classList.toggle("featured-product", featuredSet.has(item));
        return { item, node };
    });
    const divider = document.createElement(category === "pizza" ? "li" : "div");
    divider.className = "featured-divider";
    divider.setAttribute("aria-hidden", "true");

    list.append(
        ...entries.filter(({ item }) => featuredSet.has(item)).map(({ node }) => node),
        divider,
        ...entries.filter(({ item }) => !featuredSet.has(item)).map(({ node }) => node)
    );
    updateFeaturedDivider(list);
}

function updateFeaturedDivider(list) {
    const divider = list?.querySelector(":scope > .featured-divider");
    if (!divider) return;

    const entries = Array.from(list.children).filter((entry) => entry !== divider);
    const hasVisibleFeatured = entries.some((entry) => entry.classList.contains("featured-product") && !entry.hidden);
    const hasVisibleOther = entries.some((entry) => !entry.classList.contains("featured-product") && !entry.hidden);
    divider.hidden = !hasVisibleFeatured || !hasVisibleOther;
}

function updateCategorySuggestions(section) {
    if (!section) return;
    const wrap = section.querySelector(".tavern-search-wrap");
    const input = wrap?.querySelector(".tavern-search");
    const list = wrap?.querySelector(".tavern-suggest");
    if (!wrap || !input || !list) return;

    const query = input.value.trim().toLowerCase();
    const cards = Array.from(section.querySelectorAll(".coffee-item, .pizza-item"));
    list.innerHTML = "";

    if (!query) {
        list.hidden = true;
        return;
    }

    const matches = cards.filter((card) => getCategoryCardName(card).toLowerCase().includes(query));

    if (matches.length === 0) {
        const empty = document.createElement("li");
        empty.className = "tavern-suggest-empty";
        empty.textContent = "Nothing found";
        list.append(empty);
        list.hidden = false;
        return;
    }

    matches.slice(0, 8).forEach((card) => {
        const li = document.createElement("li");
        li.className = "tavern-suggest-item";
        li.setAttribute("role", "option");
        li.textContent = getCategoryCardName(card);
        li.addEventListener("mousedown", (event) => {
            event.preventDefault();
            input.value = getCategoryCardName(card);
            if (section.id === "pizza-section") applyPizzaFilters();
            if (section.id === "coffee-section") applyCoffeeFilters();
            if (section.id === "dessert-section") applyDessertFilters();
            list.hidden = true;
            openProductDetail(card);
        });
        list.append(li);
    });

    list.hidden = false;
}

document.addEventListener("mousedown", (event) => {
    if (event.target.closest(".tavern-search-wrap")) return;
    document.querySelectorAll(".tavern-suggest").forEach((list) => list.hidden = true);
});

["#dessert-section", "#alcohol-section"].forEach((selector) => {
    const section = document.querySelector(selector);
    const input = section?.querySelector(".tavern-search");
    if (input) {
        input.addEventListener("input", () => updateCategorySuggestions(section));
    }
});

renderCart();

const initialUrl = new URL(window.location.href);
initialUrl.searchParams.delete("tab");
if (["pizza", "menu", "menu-selector-frame"].includes(initialUrl.hash.slice(1).toLowerCase())) {
    initialUrl.hash = "";
}
window.history.replaceState({ kumaView: "intro" }, "", initialUrl.href);
window.scrollTo(0, 0);
