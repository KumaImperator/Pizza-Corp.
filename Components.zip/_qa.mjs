export default async function run(page, ui) {
  const R = {};
  const errors = [];
  page.on("pageerror", (e) => errors.push(e.message));
  page.on("console", (m) => { if (m.type() === "error") errors.push(m.text()); });
  const selector = page.frameLocator("#menu-selector-frame");

  await page.locator("#welcome-screen").click();

  await page.waitForTimeout(1500);
  R.menuReady = await page.evaluate(() => ({
    menuOpacity: getComputedStyle(document.querySelector("#menu-block")).opacity,
    componentLoaded: !!document.querySelector("#menu-selector-frame").contentDocument.querySelector("#stage"),
  }));

  const checks = [
    ["pizza", async () => selector.getByRole("button", { name: "Pizza", exact: true }).click()],
    ["coffee", async () => {
      await selector.locator("#dr").click();
      await selector.locator('.opt[data-n="Coffee"]').click();
    }],
    ["desserts", async () => selector.getByRole("button", { name: "Desserts", exact: true }).click()],
  ];

  for (const [tab, select] of checks) {
    await page.evaluate(() => window.scrollTo(0, 2000));
    await page.waitForTimeout(200);
    await select();
    const sectionSelector = {
      pizza: "#pizza-section",
      coffee: "#coffee-section",
      desserts: "#dessert-section",
    }[tab];
    await page.waitForFunction((selector) => {
      const section = document.querySelector(selector);
      return section && !section.hidden && section.classList.contains("category-visible");
    }, sectionSelector);
    R["tab_" + tab] = await page.evaluate((t) => {
      const map = { pizza: "#pizza-section", coffee: "#coffee-section", desserts: "#dessert-section" };
      const sec = document.querySelector(map[t]);
      return {
        scrollY: Math.round(window.scrollY),
        activeTab: document.querySelector("#menu-selector-frame").contentDocument.querySelector(".tab.active")?.textContent.trim(),
        sectionVisible: sec && !sec.hidden && sec.classList.contains("category-visible"),
      };
    }, tab);
  }

  await selector.locator("#dr").click();
  await selector.locator('.opt[data-n="Tea"]').evaluate((button) => button.click());
  R.unavailableTea = await page.evaluate(() => ({
    message: document.querySelector("#menu-selector-frame").contentDocument.querySelector("#msg").textContent.trim(),
    dessertsRemainVisible: !document.querySelector("#dessert-section").hidden,
  }));

  R.errors = errors;
  return R;
}
