(() => {
    if (window.parent === window) return;

    const stage = document.querySelector("#stage");
    const dropdown = document.querySelector("#opts");
    if (!stage) return;

    document.body.style.padding = "0";
    document.body.style.background = "transparent";

    const compactStyles = document.createElement("style");
    compactStyles.textContent = `
        #stage.compact { height: 112px; min-height: 112px; padding: 0; }
        #stage.compact.mobile-compact { height: 64px; min-height: 64px; }
    `;
    document.head.append(compactStyles);

    let dropdownOpen = false;

    const notifySize = () => {
        const style = getComputedStyle(document.body);
        window.parent.postMessage({
            type: "kuma-menu-selector-size",
            height: dropdownOpen
                ? Math.ceil(dropdown.getBoundingClientRect().bottom + 12)
                : Math.ceil(stage.offsetTop + stage.offsetHeight + parseFloat(style.paddingBottom))
        }, "*");
    };

    document.addEventListener("menusection", (event) => {
        window.parent.postMessage({
            type: "kuma-menu-selector-selection",
            detail: event.detail
        }, "*");
    });

    document.addEventListener("menudropdown", (event) => {
        dropdownOpen = event.detail.open;
        window.parent.postMessage({
            type: "kuma-menu-selector-dropdown",
            open: dropdownOpen
        }, "*");
        requestAnimationFrame(notifySize);
    });

    window.addEventListener("message", (event) => {
        if (event.source !== window.parent) return;
        if (event.data?.type === "kuma-menu-selector-theme") {
            stage.classList.toggle("theme-pizza", event.data.theme === "pizza");
            stage.classList.toggle("theme-drinks", event.data.theme === "drinks");
            stage.classList.toggle("theme-desserts", event.data.theme === "desserts");
            return;
        }
        if (event.data?.type !== "kuma-menu-selector-compact") return;
        stage.classList.toggle("compact", event.data.compact);
        stage.classList.toggle("mobile-compact", event.data.mobile === true);
        stage.classList.toggle("desktop-narrow", event.data.desktopNarrow === true);
        stage.classList.toggle("desktop-wide", event.data.desktopWide === true);
        if (Number.isFinite(event.data.headerHeight)) {
            document.documentElement.style.setProperty(
                "--menu-header-height",
                `${event.data.headerHeight}px`
            );
        }
        if (Number.isFinite(event.data.viewportHeight)) {
            document.documentElement.style.setProperty(
                "--menu-viewport-height",
                `${event.data.viewportHeight}px`
            );
        }
        window.scrollTo(0, 0);
        requestAnimationFrame(notifySize);
    });

    new ResizeObserver(notifySize).observe(stage);
    window.addEventListener("load", notifySize);
    document.fonts?.ready.then(notifySize);
})();
